package com.example.OrellTechnoSysBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrellTechnoSysBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
